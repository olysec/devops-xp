// Package test contains generic testing and benchmarking infrastructure
// for cryptographic groups and ciphersuites.
package test
