// Package xof holds implementations and testing code for the various
// extendable output functions.
package xof
