// Package examples provides a suite of tests showing how to use the different
// abstraction and protocols provided by the kyber library. To run the
// tests, simply do `go test -v` in this directory.
package examples
