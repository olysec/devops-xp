# fixbuf
Fixed length binary encoding of arbitrary structures in Go
